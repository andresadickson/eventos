# eventos
Trabalho da faculdade feito com JAVA com objetivo de desenvolver um sistema de venda de ingressos para shows e eventos.
