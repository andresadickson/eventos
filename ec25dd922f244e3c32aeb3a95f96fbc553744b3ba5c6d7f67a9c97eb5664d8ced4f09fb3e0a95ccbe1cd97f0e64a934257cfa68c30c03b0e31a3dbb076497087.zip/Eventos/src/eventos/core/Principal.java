/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventos.core;

import eventos.core.classes.Evento;
import eventos.core.classes.Ingresso;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author aschirmer
 */
public class Principal {

    public static void main(String[] args) throws ParseException {

        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

        Evento e1 = new Evento();
        e1.setNome("Show Iron Maiden");
        e1.setData(formatter.parse("04/09/2022"));
        e1.setValorUnico(630.00);
        e1.setCapacidadeMaxima(50000);

        Evento e2 = new Evento();
        e2.setNome("Festa Junina");
        e2.setData(formatter.parse("01/06/2023"));
        e2.setValorUnico(25.00);
        e2.setCapacidadeMaxima(400);

        Evento e3 = new Evento();
        e3.setNome("Fórmula 1");
        e3.setData(formatter.parse("13/11/2022"));
        e3.setValorUnico(1500.00);
        e3.setCapacidadeMaxima(3000);

        Evento e4 = new Evento();
        e4.setNome("Show da Virada");
        e4.setData(formatter.parse("31/12/2022"));
        e4.setValorUnico(320.00);
        e4.setCapacidadeMaxima(4500);

        Evento e5 = new Evento();
        e5.setNome("Jogo do Corinthians");
        e5.setData(formatter.parse("13/08/2022"));
        e5.setValorUnico(175.00);
        e5.setCapacidadeMaxima(40000);

        Ingresso i1 = new Ingresso();
        i1.setEvento(e1);
        i1.setNome("Renato Aragão");
        i1.setCpf("410.520.630-70");
        i1.setTipoIngresso("vip");
        i1.mostrarResumo();

        Ingresso i2 = new Ingresso();
        i2.setEvento(e1);
        i2.setNome("Hebert Vianna");
        i2.setCpf("456.087.269-99");
        i2.setTipoIngresso("camarote");
        i2.mostrarResumo();
        
        Ingresso i3 = new Ingresso();
        i2.setEvento(e1);
        i2.setNome("Marcelo Tas");
        i2.setCpf("998.632.456-90");
        i2.setTipoIngresso("pista");
        i2.mostrarResumo();

        e1.venderIngresso(i1);
        e1.venderIngresso(i2);
        e1.venderIngresso(i3);

        e1.ingressosVendidos();
    }

}
