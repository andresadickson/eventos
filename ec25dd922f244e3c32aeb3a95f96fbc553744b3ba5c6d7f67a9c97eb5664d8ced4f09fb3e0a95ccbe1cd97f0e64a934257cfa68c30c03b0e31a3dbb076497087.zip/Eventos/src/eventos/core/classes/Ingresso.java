/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventos.core.classes;

/**
 *
 * @author aschirmer
 */
public class Ingresso {

    private String nome;
    private String cpf;
    private Evento evento;
    private String tipoIngresso;
    private Double valorIngresso;

    public String getNome() {
        return nome;
    }

    public void setNome(String Nome) {
        this.nome = Nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTipoIngresso() {
        return tipoIngresso;
    }

    public void setTipoIngresso(String tipoIngresso) {
        this.tipoIngresso = tipoIngresso;

        switch (tipoIngresso) {
            case "pista":
                this.valorIngressoPista();
                break;
            case "camarote":
                this.valorIngressoCamarote();
                break;
            case "vip":
                this.valorIngressoVip();
                break;
            default:
                throw new AssertionError("Digite um tipo de ingresso válido.");
        }
    }

    public Evento getEvento() {
        return evento;
    }

    public void setEvento(Evento evento) {
        this.evento = evento;
    }

    public Double getValorIngresso() {
        return valorIngresso;
    }

    public void setValorIngresso(Double valorIngresso) {
        this.valorIngresso = valorIngresso;
    }
    
    

    public void mostrarResumo() {
        System.out.println("Resumo do ingresso");
        System.out.println("Evento: " + evento.getNome() + "");
        System.out.println("Titular do ingresso: " + getNome());
        System.out.println("CPF do titular: " + getCpf());
        System.out.println("Valor total do ingresso: R$ " + getValorIngresso());
        System.out.println("");
    }

    public void valorIngressoPista() {
        setValorIngresso(new IngressoPista().calcularValor(getEvento()));
    }

    public void valorIngressoCamarote() {
        setValorIngresso(new IngressoCamarote().calcularValor(getEvento()));
    }

    private void valorIngressoVip() {
        setValorIngresso(new IngressoVip().calcularValor(getEvento()));
    }
}
