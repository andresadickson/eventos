/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventos.core.classes;

/**
 *
 * @author aschirmer
 */
public class IngressoCamarote extends Ingresso {

    public double calcularValor(Evento evento) {
        return evento.getValorUnico() + (evento.getValorUnico() * 0.3);
    }
}
