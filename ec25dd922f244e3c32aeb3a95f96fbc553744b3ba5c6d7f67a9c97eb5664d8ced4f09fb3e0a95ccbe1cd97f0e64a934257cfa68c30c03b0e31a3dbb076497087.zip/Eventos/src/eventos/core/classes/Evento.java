/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eventos.core.classes;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author aschirmer
 */
public class Evento {

    private String nome;
    private Date data;
    private Double valorUnico;
    private Integer capacidadeMaxima;
    private final ArrayList<Ingresso> ingressos = new ArrayList<>();

    public Double getValorUnico() {
        return valorUnico;
    }

    public void setValorUnico(Double valorUnico) {
        this.valorUnico = valorUnico;
    }

    public Integer getCapacidadeMaxima() {
        return capacidadeMaxima;
    }

    public void setCapacidadeMaxima(Integer capacidadeMaxima) {
        this.capacidadeMaxima = capacidadeMaxima;
    }

    public List<Ingresso> getIngressos() {
        return ingressos;
    }

    public void venderIngresso(Ingresso ingresso) {
        if (this.ingressos.size() <= capacidadeMaxima - 1) {
            ingressos.add(ingresso);
        } else {
            System.out.println("------------ Evento lotado -----------");
        }
    }

    public void ingressosVendidos() {
        Integer totalIngressos = this.getIngressos().size();
        System.out.println("Ingressos vendidos para o evento " + this.getNome() + ": " + totalIngressos);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

}
